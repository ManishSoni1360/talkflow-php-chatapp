<?php
  $hostname = "sql103.epizy.com";
  $username = "	epiz_30843816";
  $password = "vhLmo9ZXZr1gNA";
  $dbname = "epiz_30843816_talkflow_database";

  $conn = mysqli_connect($hostname, $username, $password, $dbname);
  if(!$conn){
    echo "Database connection error".mysqli_connect_error();
  }
?>
